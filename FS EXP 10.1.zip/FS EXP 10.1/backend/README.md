# Todo Backend (Express + MongoDB)

## Setup
1. Install dependencies:
   ```bash
   cd backend
   npm install
   ```
2. Create a `.env` file (copy from `.env.example`) and set `MONGODB_URI` and `PORT`.
3. Start server:
   ```bash
   npm run dev
   ```
The API endpoints:
- GET /api/todos
- POST /api/todos  { title }
- PUT /api/todos/:id  { title?, completed? }
- DELETE /api/todos/:id
