import React, { useEffect, useState } from 'react';
import TodoList from './components/TodoList';

const API = process.env.API_URL || 'http://localhost:5000/api';

export default function App() {
  const [todos, setTodos] = useState([]);
  const [title, setTitle] = useState('');
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchTodos();
  }, []);

  async function fetchTodos() {
    setLoading(true);
    try {
      const res = await fetch(`${API}/todos`);
      const data = await res.json();
      setTodos(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  async function addTodo(e) {
    e.preventDefault();
    if (!title.trim()) return;
    try {
      const res = await fetch(`${API}/todos`, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ title })
      });
      const newTodo = await res.json();
      setTodos(prev => [newTodo, ...prev]);
      setTitle('');
    } catch (e) { console.error(e) }
  }

  async function toggleComplete(id, completed) {
    try {
      const res = await fetch(`${API}/todos/${id}`, {
        method: 'PUT',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ completed: !completed })
      });
      const updated = await res.json();
      setTodos(prev => prev.map(t => t._id === id ? updated : t));
    } catch (e) { console.error(e) }
  }

  async function deleteTodo(id) {
    if (!confirm('Delete this todo?')) return;
    try {
      await fetch(`${API}/todos/${id}`, { method: 'DELETE' });
      setTodos(prev => prev.filter(t => t._id !== id));
    } catch (e) { console.error(e) }
  }

  async function startEdit(todo) {
    setEditingId(todo._id);
    setTitle(todo.title);
  }

  async function saveEdit(e) {
    e.preventDefault();
    if (!title.trim()) return;
    try {
      const res = await fetch(`${API}/todos/${editingId}`, {
        method: 'PUT',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ title })
      });
      const updated = await res.json();
      setTodos(prev => prev.map(t => t._id === editingId ? updated : t));
      setEditingId(null);
      setTitle('');
    } catch (e) { console.error(e) }
  }

  return (
    <div className="container">
      <h1>Todo App</h1>
      <form onSubmit={editingId ? saveEdit : addTodo} className="add-form">
        <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Add todo..." />
        <button type="submit">{editingId ? 'Save' : 'Add'}</button>
        {editingId && <button type="button" onClick={() => { setEditingId(null); setTitle(''); }}>Cancel</button>}
      </form>

      {loading ? <p>Loading...</p> : <TodoList todos={todos} onToggle={toggleComplete} onDelete={deleteTodo} onEdit={startEdit} />}
    </div>
  );
}
