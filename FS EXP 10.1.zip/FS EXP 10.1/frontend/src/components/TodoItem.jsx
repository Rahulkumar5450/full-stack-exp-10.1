import React from 'react';

export default function TodoItem({ todo, onToggle, onDelete, onEdit }) {
  return (
    <li className={`todo-item ${todo.completed ? 'completed' : ''}`}>
      <input type="checkbox" checked={!!todo.completed} onChange={() => onToggle(todo._id, todo.completed)} />
      <span className="title">{todo.title}</span>
      <div className="actions">
        <button onClick={() => onEdit(todo)}>Edit</button>
        <button onClick={() => onDelete(todo._id)}>Delete</button>
      </div>
    </li>
  );
}
