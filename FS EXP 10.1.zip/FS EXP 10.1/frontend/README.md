# Todo Frontend (React, Parcel)

## Setup
1. Install dependencies:
   ```bash
   cd frontend
   npm install
   ```
2. Start dev server:
   ```bash
   npm start
   ```
By default, the app expects the backend API at http://localhost:5000/api.
