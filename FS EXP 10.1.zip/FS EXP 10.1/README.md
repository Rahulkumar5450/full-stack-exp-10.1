# Todo Full-Stack App (Ready-to-run)

## Contents
- backend: Node.js + Express + MongoDB (Mongoose)
- frontend: React (Parcel bundler)

## Quick setup (local)
1. Make sure you have Node.js and npm installed.
2. Start MongoDB (e.g., `mongod` or use a MongoDB Atlas connection).
3. Backend:
   ```bash
   cd backend
   npm install
   cp .env.example .env
   # edit .env if needed, then:
   npm run dev
   ```
4. Frontend:
   ```bash
   cd frontend
   npm install
   npm start
   ```
5. Open http://localhost:3000

## Notes
- If you use MongoDB Atlas, replace MONGODB_URI in backend/.env with your connection string.
- This project is minimal and intended for demonstration and evaluation.
